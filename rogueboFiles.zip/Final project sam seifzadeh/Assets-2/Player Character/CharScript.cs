using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CharScript : MonoBehaviour
{
    [Range(1,12)]
    public float moveSpeed = 6F;
    public float maxHealth = 15F;
    public float baseDamage = 1f;

    private double timeSinceFiring = 0F;

    public Rigidbody2D charRigidbody;
    
    public HealthbarBehaviour healthbarControl;
    public Canvas canvas; //healthbar canvas

    public Animator charAnim;

    public int currentWeaponIndex;
    //[SerializeField]
    public GameObject currentGun;
    //[SerializeField]
    public GameObject[] firearms;

    private float gunOffset = .32f;

    public GameObject meleeWeapon;

    public bool alive;

    public TMP_Text currWeaponText;

    // Start is called before the first frame update
    void Start()
    {
        gameObject.layer = 3;
        currWeaponText = GameObject.Find("WeaponTMP").GetComponent<TMP_Text>();
        currWeaponText.text = "Starting Pistol";

        alive = true;
        //healthbar stuff
        healthbarControl = GetComponent<HealthbarBehaviour>();
        healthbarControl.MaxHitpoints = maxHealth;
        Canvas currCanvas = Instantiate(canvas);
        healthbarControl.ManualStart(currCanvas);
        currCanvas.GetComponent<SliderController>().ManualStart(gameObject);


        charAnim = GetComponent<Animator>();
        charRigidbody = GetComponent<Rigidbody2D>();

        meleeWeapon = GameObject.Find("Machete");

        currentWeaponIndex = 0;
        currentGun = Instantiate(firearms[0], transform.position, transform.rotation, gameObject.transform); //position should be a bit different, based on character's facing tbh.

    }


    // Update is called once per frame
    void Update()
    {
        if (alive)
        {
            bool moving = move();

            swapWeapon();

            if (Input.GetMouseButton(0))
            {
                Debug.Log("base damage: " + baseDamage);
                currentGun.GetComponent<Weapon>().nonHit(gameObject.layer);
                currentGun.GetComponent<Weapon>().Fire(baseDamage);
                Debug.Log("Firing " + currentGun.name);
                timeSinceFiring = 0f;

            }
            timeSinceFiring += Time.deltaTime;

            if (Input.GetMouseButtonDown(1))
            {
                meleeWeapon.GetComponent<MacheteScript>().Attack();
            }


            adjustFacingAndAim(moving);

        }

    }



    private bool move()
    {
        bool moving = false;
        charRigidbody.velocity = new Vector2(0, 0); //resets velocity to 0 if none of the keys are held down

        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            charRigidbody.velocity = new Vector2(-1 * moveSpeed, charRigidbody.velocity.y);
            if (timeSinceFiring > .3f)
            {
                charAnim.Play("LeftRun");
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                transform.localScale = new Vector3(1, 1, 1); //this might go outside this if statement?
            }
            //currentGun.transform.localScale = new Vector3(1, 1, 1);
            moving = true;
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {

            charRigidbody.velocity = new Vector2(1 * moveSpeed, charRigidbody.velocity.y);
            if (timeSinceFiring > .3f) 
            {
                charAnim.Play("LeftRun");
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                transform.localScale = new Vector3(-1, 1, 1); //this might go outside this if statement?
            }
            //currentGun.transform.localScale = new Vector3(-1, 1, 1);
            moving = true;

        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            
            charRigidbody.velocity = new Vector2(charRigidbody.velocity.x, 1 * moveSpeed);
            if (charRigidbody.velocity.x == 0 && timeSinceFiring > .3f)
            {
                charAnim.Play("UpwardRun");
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 99;
                currentGun.transform.localPosition = new Vector3(0, gunOffset, 0);
            }
                moving = true;
        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {
            
            charRigidbody.velocity = new Vector2(charRigidbody.velocity.x, -1 * moveSpeed);
            if (charRigidbody.velocity.x == 0 && timeSinceFiring > .3f)
            {
                charAnim.Play("DownwardRun");
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(0, -gunOffset, 0);
            }
            moving = true;
        }

        //normalize diagonal movement (so it's not faster than cardinal movement)
        if (charRigidbody.velocity.magnitude > moveSpeed)  //should maybe also check if hitting a wall, to avoid dragging/reducing speed when moving diagonally against a wall.
        {
            charRigidbody.velocity = charRigidbody.velocity.normalized * moveSpeed; //approx root2 of x and y velocities
        }
        //Debug.Log("char velocity: " + charRigidbody.velocity);

        //if (charRigidbody.velocity.magnitude == 0 && timeSinceFiring > .3f)
        //{
        //    charAnim.Play("Idle");
        //}

        return moving;
    }

    public void swapWeapon()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            // next weapon
            if (currentWeaponIndex < firearms.Length - 1)
            {
                currentWeaponIndex += 1;
            }
            else
            {
                currentWeaponIndex = 0;
            }
            Destroy(currentGun);
            currentGun = Instantiate(firearms[currentWeaponIndex], transform.position, transform.rotation, gameObject.transform);
            currWeaponText.text = currentGun.GetComponent<Weapon>().getName();
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            // previous weapon
            if (currentWeaponIndex > 0)
            {
                currentWeaponIndex -= 1;
            }
            else
            {
                currentWeaponIndex = firearms.Length - 1;
            }
            Destroy(currentGun);
            currentGun = Instantiate(firearms[currentWeaponIndex], transform.position, transform.rotation, gameObject.transform);
            currWeaponText.text = currentGun.GetComponent<Weapon>().getName();
        }
    }

    private void adjustFacingAndAim(bool moving)
    {
        //Transform.LookAt(Transform target)  might do this more easily. Eh. LookAt rotates on all 3 axes at once, so it'll pull some Paper Mario shit.
        //gun rotation/aiming. Will need to adjust to pivot around the character's hand, and change the character's facing based on mouse position
        Vector2 mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 aimDirection = mousePosition - charRigidbody.position;
        float aimAngle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg - 90f;
        float currGunAngle = Mathf.Atan2(currentGun.transform.rotation.y, currentGun.transform.rotation.x) * Mathf.Rad2Deg - 90f;
        //currentGun.transform.rotation = Quaternion.FromToRotation(currentGun.transform.forward, new Vector3(0, 0, aimAngle));
        //currentGun.transform.Rotate(0, 0, aimAngle, Space.World);
        Quaternion aimVector = Quaternion.Euler(0, 0, (aimAngle - currGunAngle) + 90f);
        currentGun.transform.rotation = aimVector;
        GameObject meleeWeaponHolder = GameObject.Find("macheteHolder");
        meleeWeaponHolder.transform.rotation = aimVector;

        float currZAngle = aimVector.eulerAngles.z;

        //Setting player to face direction of mouse when firing or recently fired.
        if (timeSinceFiring <= .3f)
        {
            //45-135 left, 135-225 down, 225-315 right, 315-45 up

            if (currZAngle > 215 && currZAngle < 315) //right
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                if (moving)
                    charAnim.Play("LeftRun");
                else
                    charAnim.Play("LeftIdle");
                transform.localScale = new Vector3(-1, 1, 1);
                //currentGun.transform.localScale = new Vector3(-1, 1, 1);
            }
            else if (currZAngle > 135 && currZAngle < 315) //down
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(0, -gunOffset, 0);
                if (moving)
                    charAnim.Play("DownwardRun");
                else
                    charAnim.Play("Idle");

            }
            else if (currZAngle > 44 && currZAngle < 315) //left
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                if (moving)
                    charAnim.Play("LeftRun");
                else
                    charAnim.Play("LeftIdle");
                transform.localScale = new Vector3(1, 1, 1);
                //currentGun.transform.localScale = new Vector3(1, 1, 1);
            }
            else //up
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 99;
                currentGun.transform.localPosition = new Vector3(0, gunOffset, 0);
                if (moving)
                    charAnim.Play("UpwardRun");
                else
                    charAnim.Play("UpwardIdle");
            }
        }
        else if (!moving)
        {
            if (currZAngle > 215 && currZAngle < 315) //right
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                charAnim.Play("LeftIdle");
                transform.localScale = new Vector3(-1, 1, 1);
                //currentGun.transform.localScale = new Vector3(-1, 1, 1);
            }
            else if (currZAngle > 135 && currZAngle < 315) //down
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(0, -gunOffset, 0);
                charAnim.Play("Idle");
            }
            else if (currZAngle > 44 && currZAngle < 315) //left
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 101;
                currentGun.transform.localPosition = new Vector3(-gunOffset, -.1f, 0);
                charAnim.Play("LeftIdle");
                transform.localScale = new Vector3(1, 1, 1);
                //currentGun.transform.localScale = new Vector3(1, 1, 1);
            }
            else //up
            {
                currentGun.GetComponent<SpriteRenderer>().sortingOrder = 99;
                currentGun.transform.localPosition = new Vector3(0, gunOffset, 0);
                charAnim.Play("UpwardIdle");
            }
        }
    }

}
