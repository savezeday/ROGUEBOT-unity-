using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This script attaches to the Enemy GameObjects.
//Controls enemy movement and based on its awareness of the player.
public class EnemyMovement : MonoBehaviour
{

//Movement speed and rotation speed variables.
[SerializeField]
private float _speed;

[SerializeField]
private float _rotationSpeed;

private Rigidbody2D _rigidbody;
private PlayerAwarenessController _playerAwarenessController;
private Vector2 _targetDirection;

private void Awake()
{
    _rigidbody = GetComponent<Rigidbody2D>();
    _playerAwarenessController = GetComponent<PlayerAwarenessController>();
}
    
    private void FixedUpdate()
    {
        UpdateTargetDirection();
        RotateTowardsTarget();
        SetVelocity();
    }

    //Checks if enemy is aware of player
    private void UpdateTargetDirection()
    {
        if (_playerAwarenessController.AwareOfPlayer)
        {
            _targetDirection = _playerAwarenessController.DirectionToPlayer;
        }
        else
        {
            _targetDirection = Vector2.zero;
        }
    }
    //Rotates enemy in direction of player if they are detected
    private void RotateTowardsTarget()
    {
        if (_targetDirection == Vector2.zero)
        {
            return;
        }
        
        Quaternion targetRotation = Quaternion.LookRotation(transform.forward, _targetDirection);
        Quaternion rotation = Quaternion.RotateTowards(transform.rotation, targetRotation, _rotationSpeed * Time.deltaTime);

        _rigidbody.SetRotation(rotation);
        

    }
    //Sets enemy velocity to zero if player is no longer in range 
    //Else Sets velocity to the direction the enemy is facing multiplied by _speed
    private void SetVelocity()
    {
        if (_targetDirection == Vector2.zero)
        {
            _rigidbody.velocity = Vector2.zero;
        }
        else
        {
            _rigidbody.velocity = transform.up * _speed;
        }
    }


}
