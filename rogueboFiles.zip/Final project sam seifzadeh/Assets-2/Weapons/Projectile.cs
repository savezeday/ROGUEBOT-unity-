using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    [Range(1, 30)]
    //[SerializeField] 
    public float speed;

    [Range(1, 14)]
    //[SerializeField] 
    public float lifeTime;

    public float damage = 1f;

    public Rigidbody2D rb;

    public bool firedByEnemy = false; //check for friendly fire in collisions

    public static bool changedRooms = false;


    // Start is called before the first frame update
    void Start()
    {
        
        //Physics2D.IgnoreLayerCollision(gameObject.layer, gameObject.layer); //ignore inter-bullet collisions. doesn't seem to work
        rb = GetComponent<Rigidbody2D>();
        Destroy(gameObject, lifeTime);
    }


    private void FixedUpdate()
    {
        move();

        //if (changedRooms)
        //{
        //    changedRooms = false;
        //    Destroy(gameObject);
        //}
    }

    public virtual void move() //virtual so it can be overriden by child classes (ricochet moves differently, and other exotic weapons might as well)
    {
        rb.velocity = transform.up * speed;
    }

    public void setNonCollisionLayer(int nonTargetLayer)
    {
        gameObject.layer = 6;
        Physics2D.IgnoreLayerCollision(gameObject.layer, nonTargetLayer); //ignore collisions between (layer 20(bullets), and 100(player char layer))
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.CompareTag("Player") || collision.gameObject.CompareTag("Enemy"))
        {
            var victim = collision.collider.GetComponent<HealthbarBehaviour>();
            Debug.Log("fired by enemy: " + firedByEnemy);

            if (firedByEnemy && collision.gameObject.CompareTag("Player")) //fired by enemy, hits player
            {
                //player takes damage
                Debug.Log("projectile hit player");
                victim.TakeHit(damage);
                Destroy(gameObject);
            }
            else if (!firedByEnemy && collision.gameObject.CompareTag("Enemy")) //fired by player, hits enemy
            {
                //enemy takes damage
                Debug.Log("projectile hit enemy");
                victim.TakeHit(damage);
                Destroy(gameObject);
            }
        }
        else if (collision.gameObject.CompareTag("Wall")) //hits wall
        {
            hitWall(collision);
        }
    }

    public virtual void hitWall(Collision2D collision) //virtual so wall-impact behavior can be easily overridden by child class
    {
        //Debug.Log("projectile hit wall");
        Destroy(gameObject);
    }

}


/*
 *
 *in onCollision
 *  var enemy = collision.collider.GetComponent<HealthbarBehaviour>();
    if (enemy)
    {
      enemy.TakeHit(1);
    }
    Destroy(gameObject);
}
*/