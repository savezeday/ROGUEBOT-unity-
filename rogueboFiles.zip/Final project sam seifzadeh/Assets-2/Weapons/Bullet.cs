//Artim Bullet script

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : Projectile
{
    //things in here should only be to override Projectile stuff, or to add unique features for this specific projectile

    // Start is called before the first frame update
    void Start()
    {
        lifeTime = 3f;
        //rb = GetComponent<Rigidbody2D>();
        Destroy(gameObject, lifeTime);
    }



}

