using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RicochetGun : Weapon
{

    public GameObject ricochetBulletPrefab;
    public Transform firePoint;

    public float fireRate = .28f;
    public float timeToFire = 0f;

    private int nonTargetLayer;

    public override void Fire(float baseDamage)
    {
        timeToFire -= Time.deltaTime;

        if (Input.GetMouseButtonDown(0))
        {
            timeToFire = 0f;
        }

        if (timeToFire <= 0f)
        {
            timeToFire = fireRate;
            Debug.Log("Firing ricochet gun...");
            GameObject ricochetBullet = Instantiate(ricochetBulletPrefab, firePoint.position, firePoint.rotation);
            ricochetBullet.GetComponent<Projectile>().damage *= baseDamage;

            ricochetBullet.GetComponent<Projectile>().setNonCollisionLayer(nonTargetLayer);
        }
    }

    public override void nonHit(int givenLayer)
    {
        nonTargetLayer = givenLayer;
    }

    public override string getName()
    {
        return "Ricochet Gun";
    }
}
