using UnityEngine;

public class Ricochet : Projectile
{
    //things in here should only be to override Projectile stuff, or to add unique features for this specific projectile

    public int maxBounces = 3;
    private int bounces = 0;


    private Vector2 currVelocity;

    void Start()
    {
        lifeTime = 7f;
        Destroy(gameObject, lifeTime);
        currVelocity = transform.up * speed;
        //halo = GetComponent<Halo>();
    }


    public override void move()
    {
        rb.velocity = currVelocity;
    }

    // If we want the ricochet bullet to pierce enemies, copy the whole OnCollisionEnter2D function into here and remove the Destroy(gameObject) lines from Enemy and Player impacts

    public override void hitWall(Collision2D collision)
    {
        if (bounces < maxBounces)
        {
            bounces++;
            
            Vector2 normal = collision.GetContact(0).normal;
            Vector2 newDirection = Vector2.Reflect(currVelocity, normal);
            currVelocity = newDirection;

            damage = damage * 2;

            GetComponent<SpriteRenderer>().color = new Color(((float)bounces/(maxBounces+1)), 0f, 0f, 1f);

            //RenderSettings.haloStrength += 2f;        in the Inspector -> add component -> Effects -> Halo, then you can change its size with the RenderSettings line here.
            //The issue is the halo is behind everything else. It exists in the scene, but isn't visible except where the scene is otherwise empty. apparently giving sprites a material will fix it?
        }
        else
        {
            Destroy(gameObject);
        }
    }

}
