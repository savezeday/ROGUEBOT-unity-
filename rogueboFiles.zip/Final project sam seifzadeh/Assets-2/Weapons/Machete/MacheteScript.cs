using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MacheteScript : MonoBehaviour
{
    public Animator animator;
    public float delay = 0.3f;
    public Transform circleOrigin;
    public float radius = 1;
    public float meleeDamage = 2;

    public void Attack()
    {
        Debug.Log("Using Machete...");
        animator.SetTrigger("Attack");
        StartCoroutine(DelayAttack());
    }

   private IEnumerator DelayAttack()
    {
        yield return new WaitForSeconds(delay);
    }

    //a function purely for development. Doesn't get called during runtime, but while mousing over the object in the scene view while editing
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Vector3 position = circleOrigin == null ? Vector3.zero : circleOrigin.position;
        Gizmos.DrawWireSphere(position, radius);
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("machete hitting something");
        //foreach (Collider2D collider in Physics2D.OverlapCircleAll(circleOrigin.position, radius))
        //{
            Debug.Log("machete hitting: " + collision.name);
            HealthbarBehaviour enemy;
            if (enemy = collision.GetComponent<HealthbarBehaviour>())
            {
                enemy.TakeHit(meleeDamage);
            }
        //}
    }
    
}
