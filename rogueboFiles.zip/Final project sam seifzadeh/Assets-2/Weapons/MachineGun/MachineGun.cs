using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MachineGun : Weapon
{

    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate;
    public float timeToFire = 0f;

    private int nonTargetLayer;

    public override void Fire(float baseDamage)
    {
        Debug.Log("Firing machine gun...");
        
        if (Input.GetMouseButtonDown(0))
        {
            timeToFire = 0f;
        }

        if (timeToFire <= 0f)
        {
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            bullet.GetComponent<Projectile>().damage *= baseDamage;
            timeToFire = fireRate;

            bullet.GetComponent<Projectile>().setNonCollisionLayer(nonTargetLayer);
        }
        else
        {
            timeToFire -= Time.deltaTime;
        }

    }

    public override void nonHit(int givenLayer)
    {
        nonTargetLayer = givenLayer;
    }

    public override string getName()
    {
        return "Machine Gun";
    }
}